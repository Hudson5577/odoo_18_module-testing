{
  'name': 'Real Estate',
  'depends': [
      'base',
  ],
  'data': [
      'views/estate_property_views.xml',
      'views/estate_menus.xml',
      'security/ir_model_access.csv',
  ],
  'application': True
}